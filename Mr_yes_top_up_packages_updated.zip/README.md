Updated Mr. yes top up package demo. Replace root index.html in GitHub and commit. Package cards and dropdown are synchronized. All prices are demo only; no real order, payment, storage or delivery.
